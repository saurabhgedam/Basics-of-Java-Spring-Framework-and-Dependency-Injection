package Required;

import org.springframework.beans.factory.annotation.Required;

public class Name {
	String name;

	public String getName() {
		return name;
	}
	@Required
	public void setName(String name) {
		this.name = name;
	}

	public void print(){
		System.out.println("Name is: "+name);
	}
}
