package ListInheritance;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		ApplicationContext cxt = new ClassPathXmlApplicationContext("Beans.xml");
		Info infoObj = (Info) cxt.getBean("infoList2");
		infoObj.printAll();

	}

}
