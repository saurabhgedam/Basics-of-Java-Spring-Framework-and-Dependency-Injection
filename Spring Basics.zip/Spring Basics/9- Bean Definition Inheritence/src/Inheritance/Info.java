package Inheritance;

public class Info {


	public Players getFirstPlayer() {
		return firstPlayer;
	}


	public void setFirstPlayer(Players firstPlayer) {
		this.firstPlayer = firstPlayer;
	}


	public Players getSecondPlayer() {
		return secondPlayer;
	}


	public void setSecondPlayer(Players secondPlayer) {
		this.secondPlayer = secondPlayer;
	}


	public Players getThirdPlayer() {
		return thirdPlayer;
	}


	public void setThirdPlayer(Players thirdPlayer) {
		this.thirdPlayer = thirdPlayer;
	}


	Players firstPlayer;
	Players secondPlayer;
	Players thirdPlayer;
	
	
	public void decscription(){
		System.out.println("Name: "+firstPlayer.getName()+"\nAge is: "+firstPlayer.getAge()+" \nTeam is: "+firstPlayer.getTeam()+"\n\n");
		System.out.println("Name: "+secondPlayer.getName()+"\nAge is: "+secondPlayer.getAge()+"\nTeam is: "+secondPlayer.getTeam()+"\n\n");
		System.out.println("Name: "+thirdPlayer.getName()+"\nAge is: "+thirdPlayer.getAge()+"\nTeam is: "+thirdPlayer.getTeam()+"\n\n");
	}
		
}
