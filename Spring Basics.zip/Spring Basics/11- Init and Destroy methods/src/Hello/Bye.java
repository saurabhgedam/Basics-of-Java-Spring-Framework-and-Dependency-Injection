package Hello;

public class Bye {

	String str;
	public String getStr() {
		return str;
	}
	public void setStr(String str) {
		this.str = str;
	}
	public void talk()
	{
		System.out.println(str);
	}
	
	 public void init(){
		 
			System.out.println("\nBye bean is starting\n");
		}
		 
		public void cleanUp(){
				 
			 System.out.println("Bye bean is ending");
		}
}
