package Pack;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Description {

	Name nameObj;
	
	public Name getNameObj() {
		return nameObj;
	}

	@Resource(name="name1")
	public void setNameObj(Name nameObj) {
		this.nameObj = nameObj;
	}

	
	public void description()
	{
		System.out.println("lets go");
		System.out.println("Name is: "+ nameObj.name);
		}
	
	@PostConstruct
	public void nameInit()
	{
		System.out.println("Name bean init");
	}
	@PreDestroy
	public void nameEnd()
	{
		System.out.println("Name bean init");
	}
}
