package Hello;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.beans.factory.BeanFactory;

public class MainClass {

	public static void main(String[] args) {
		AbstractApplicationContext cxt = new ClassPathXmlApplicationContext("beans.xml");
		cxt.registerShutdownHook();
		Hello helloObj = (Hello)  cxt.getBean("hello");
		Bye byeObj = (Bye)  cxt.getBean("bye");
		helloObj.talk();
		byeObj.talk();
		
		
	}

}
