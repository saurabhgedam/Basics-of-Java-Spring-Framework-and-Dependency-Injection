package Pack;

import org.springframework.context.ApplicationEvent;

public class AnyEvent extends ApplicationEvent{

	public AnyEvent(Object source) {
		super(source);
	}

public String toString()
{
	return "this is the current event";
}

}
