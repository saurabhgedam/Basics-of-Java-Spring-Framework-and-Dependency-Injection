package Interfaces;

public class Cricketers implements Players {

	String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSport() {
		return sport;
	}
	public void setSport(String sport) {
		this.sport = sport;
	}
	String sport;
	String moto="Hit it!";
	@Override
	public void describe() {
	
		System.out.println("Name is: "+name+" he plays :"+sport+" and he likes to "+moto);
	}

	
}