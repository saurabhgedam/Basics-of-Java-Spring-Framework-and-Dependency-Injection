package Pack;

public class Info {

	
	public Boy getBoy1() {
		return boy1;
	}

	public void setBoy1(Boy boy1) {
		this.boy1 = boy1;
	}

	public Boy getBoy2() {
		return boy2;
	}

	public void setBoy2(Boy boy2) {
		this.boy2 = boy2;
	}

	Boy boy1;
	Boy boy2;
	
	public void description(){
		System.out.println("\nName is: "+boy1.name+"\n Age is: "+boy1.age+"\n Weight is: "+boy1.weight);
		System.out.println("\nName is: "+boy2.name+"\n Age is: "+boy2.age+"\n Weight is: "+boy2.weight);
	}
}
