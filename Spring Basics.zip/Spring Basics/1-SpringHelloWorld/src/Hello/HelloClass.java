package Hello;

public class HelloClass {
	
	public void sayHello()
	{
		System.out.println("Hello World !");
	}

}
