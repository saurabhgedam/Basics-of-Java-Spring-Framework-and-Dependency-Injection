package Hello;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Hello implements InitializingBean, DisposableBean {

	String str;
	public String getStr() {
		return str;
	}
	public void setStr(String str) {
		this.str = str;
	}
	public void talk()
	{
		System.out.println(str);
	}
	 public void init(){
		 
		System.out.println("\nHello bean is starting\n");
	}
	 
	public void cleanUp(){
			 
		 System.out.println("\nHello bean is ending\n");
	}

	
	@Override
	public void destroy() throws Exception {
		
		System.out.println("\nGlobal bean is closing\n");
	}
	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("\nGlobal bean is starting\n");
	}

}
