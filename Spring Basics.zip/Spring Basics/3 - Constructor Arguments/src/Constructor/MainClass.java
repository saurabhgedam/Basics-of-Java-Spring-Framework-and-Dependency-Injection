package Constructor;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	    public static void main(String[] args) {
		ApplicationContext cxt = new ClassPathXmlApplicationContext("beans.xml");
		Triangle triObj1 = (Triangle) cxt.getBean("triangle1");
		triObj1.triMethod();

	    
		Triangle triObj2 = (Triangle) cxt.getBean("triangle2");
		triObj2.triMethod();
	    

		Triangle triObj3 = (Triangle) cxt.getBean("triangle3");
		triObj3.triMethod();
	    
		
		Triangle triObj4 = (Triangle) cxt.getBean("triangle4");
		triObj4.triMethod();
		
		Triangle triObj5 = (Triangle) cxt.getBean("triangle5");
		triObj5.triMethod();
		
		
	    }

}
