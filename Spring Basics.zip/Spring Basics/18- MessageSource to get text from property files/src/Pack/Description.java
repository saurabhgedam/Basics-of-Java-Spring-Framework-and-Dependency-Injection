package Pack;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Description {

	Name nameObj;
	@Autowired
	MessageSource msgsrc;

	public MessageSource getMsgsrc() {
		return msgsrc;
	}
	
	public void setMsgsrc(MessageSource msgsrc) {
		this.msgsrc = msgsrc;
	}
	
	public Name getNameObj() {
		return nameObj;
	}

	@Resource(name="name1")
	public void setNameObj(Name nameObj) {
		this.nameObj = nameObj;
	}

	
	public void description()
	{
		System.out.println("Name is: "+ nameObj.name);
		System.out.println(msgsrc.getMessage("descriptionGreeting", null, "Default Message: something went wrong!", null));
	}
	
	@PostConstruct
	public void nameInit()
	{
		System.out.println("Name bean init");
	}
	@PreDestroy
	public void nameEnd()
	{
		System.out.println("Name bean init");
	}
}
