package HelloAppContext;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		ApplicationContext cxt = new ClassPathXmlApplicationContext("beans.xml");
		HelloClass helloObj = (HelloClass) cxt.getBean("hello");
		helloObj.sayHello();
	
		HelloClass helloObj2 = (HelloClass) cxt.getBean("hello2");
		helloObj2.sayHello();
	}

}
