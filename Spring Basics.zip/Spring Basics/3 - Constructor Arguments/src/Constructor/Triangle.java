package Constructor;

public class Triangle {

	private int base;
	private int height;
	private String type;

	public Triangle(int base, int height, String type)
	{
		this.base = base;
		this.height = height;
		this.type = type;
	}
	
	public Triangle(int base, int height)
	{
		this.base = base;
		this.height = height;
	}
	
	public Triangle(int base, String type)
	{
		this.base = base;
		this.type = type;
	}
	

	public Triangle(int height)
	{
		this.height = height;
	}
	
	public Triangle(String type)
	{
		this.type = type;
	}
	
	

	
	
	public void triMethod()
	{
		System.out.println("Base is: "+base);
		System.out.println("Height is: "+height);
		System.out.println("Type is: "+type+"\n");
	}
}

