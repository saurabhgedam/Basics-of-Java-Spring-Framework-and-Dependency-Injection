package Interfaces;

public interface Players {

	public void describe();
}
