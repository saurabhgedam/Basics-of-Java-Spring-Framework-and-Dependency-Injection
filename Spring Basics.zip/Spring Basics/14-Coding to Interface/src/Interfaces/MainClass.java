package Interfaces;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
	
		ApplicationContext cxt = new ClassPathXmlApplicationContext("beans.xml");
		Players players1 =  (Players) cxt.getBean("cricketer1");
		players1.describe();
		
		Players players2 =  (Players) cxt.getBean("footballer1");
		players2.describe();
	}

}
