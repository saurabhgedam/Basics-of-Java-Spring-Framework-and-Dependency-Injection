package Soccer;

public class Description {

	Players player1;
	Players player2;
	Players player3;
	
	public Players getPlayer1() {
		return player1;
	}

	public void setPlayer1(Players player1) {
		this.player1 = player1;
	}

	public Players getPlayer2() {
		return player2;
	}

	public void setPlayer2(Players player2) {
		this.player2 = player2;
	}

	public Players getPlayer3() {
		return player3;
	}

	public void setPlayer3(Players player3) {
		this.player3 = player3;
	}

	
	public void playerDescriptions()
	{
		System.out.println("Name: "+player1.getName()+"\nAge: "+player1.getAge()+"\nTeam: "+player1.getTeam()+"\n\n");
		System.out.println("Name: "+player2.name+"\nAge: "+player2.getAge()+"\nTeam: "+player2.getTeam()+"\n\n");
		System.out.println("Name: "+player3.name+"\nAge: "+player3.getAge()+"\nTeam: "+player3.getTeam()+"\n\n");

	}
}
