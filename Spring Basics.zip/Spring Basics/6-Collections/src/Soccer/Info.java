package Soccer;

import java.util.List;

public class Info {


	public List<Players> players;
	
	public List<Players> getPlayers() {
		return players;
	}

	public void setPlayers(List<Players> players) {
		this.players = players;
	}
	
	public void printAll(){
	for(Players p : players)
	{
		System.out.println("Name: "+p.getName()+ "\nAge is: "+p.getAge()+"\nTeam is: "+p.getTeam()+"\n\n");
	}
	}
}
	
