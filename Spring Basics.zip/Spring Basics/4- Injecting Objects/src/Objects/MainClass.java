package Objects;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext cxt = new ClassPathXmlApplicationContext("beans.xml");
		Classroom classObj =(Classroom) cxt.getBean("classroom1");
		classObj.printList();
	}

	
}
