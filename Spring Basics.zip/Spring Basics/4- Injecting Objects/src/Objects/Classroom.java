package Objects;

public class Classroom {
	Students student1;
	Students student2;
	
	public Students getStudent1() {
		return student1;
	}



	public void setStudent1(Students student1) {
		this.student1 = student1;
	}



	public Students getStudent2() {
		return student2;
	}



	public void setStudent2(Students student2) {
		this.student2 = student2;
	}


	public void printList()
	{
		System.out.println("Student 1 name is: "+ student1.name +" and age is: "+student1.age);
		System.out.println("student 2 name is: "+ student2.name +" and age is: "+student2.age);
	}
	
}
