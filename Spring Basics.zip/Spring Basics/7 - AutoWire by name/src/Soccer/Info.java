package Soccer;

import java.util.List;

public class Info {

	Players player1;
	Players player2;
	Players player3;
	public Players getPlayer1() {
		return player1;
	}
	public void setPlayer1(Players player1) {
		this.player1 = player1;
	}
	public Players getPlayer2() {
		return player2;
	}
	public void setPlayer2(Players player2) {
		this.player2 = player2;
	}
	public Players getPlayer3() {
		return player3;
	}
	public void setPlayer3(Players player3) {
		this.player3 = player3;
	}
	
	public void printAll(){
	System.out.println("Name: "+player1.getName()+ "\nAge is: "+player1.getAge()+"\nTeam is: "+player1.getTeam()+"\n\n");
	System.out.println("Name: "+player2.getName()+ "\nAge is: "+player2.getAge()+"\nTeam is: "+player2.getTeam()+"\n\n");
	System.out.println("Name: "+player3.getName()+ "\nAge is: "+player3.getAge()+"\nTeam is: "+player3.getTeam()+"\n\n");
	}
}
	
