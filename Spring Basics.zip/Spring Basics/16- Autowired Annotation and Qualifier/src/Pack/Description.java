package Pack;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Description {

	Name nameObj;
	
	public Name getNameObj() {
		return nameObj;
	}


	@Autowired
	@Qualifier("thisOne")
	public void setNameObj(Name nameObj) {
		this.nameObj = nameObj;
	}

	
	public void description()
	{
		System.out.println("Name is: "+ nameObj.name);
	}
	
}
