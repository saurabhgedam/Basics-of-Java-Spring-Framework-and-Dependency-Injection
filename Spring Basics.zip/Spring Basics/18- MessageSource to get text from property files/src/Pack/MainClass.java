package Pack;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {

		AbstractApplicationContext cxt = new ClassPathXmlApplicationContext("beans.xml");
		cxt.registerShutdownHook();
		Description desObj = (Description) cxt.getBean("des");
		System.out.println(cxt.getMessage("greeting1",null,"This is the default Greeting if the given parameter is missing", null));
		System.out.println(cxt.getMessage("greeting2",null,"this message is showing up because greeting2 is not defined", null));
		desObj.description();

	}

}
